package com.acme;

public class Elemento {

    private int valor;

    public Elemento(int valor) {
        this.valor = valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public int getValor() {
        return this.valor;
    }

}
